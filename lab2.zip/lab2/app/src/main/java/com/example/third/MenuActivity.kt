package com.example.third

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MenuActivity : AppCompatActivity() {

    private lateinit var textViewName: TextView
    private lateinit var imageViewProfile: ImageView
    private var selectedImagePath: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        textViewName = findViewById(R.id.textView2)
        imageViewProfile = findViewById(R.id.imageView2)
        val logOutButton = findViewById<Button>(R.id.button)

        logOutButton.setOnClickListener {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
            finish()
        }

        imageViewProfile.setOnClickListener {
            pickImageGallery()
        }

        val sharedPreferences: SharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        val name = sharedPreferences.getString("name", "")
        val imagePath = sharedPreferences.getString("imagePath", "")

        textViewName.text = name
        if (!imagePath.isNullOrEmpty()) {
            imageViewProfile.setImageURI(Uri.parse(imagePath))
        }
    }

    private fun pickImageGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = "image/*"
        startActivityForResult(intent, RegistrationActivity.IMAGE_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == RegistrationActivity.IMAGE_REQUEST_CODE && resultCode == RESULT_OK) {
            val selectedImageUri = data?.data
            selectedImagePath = selectedImageUri?.toString()
            imageViewProfile.setImageURI(selectedImageUri)
        }
    }

}
