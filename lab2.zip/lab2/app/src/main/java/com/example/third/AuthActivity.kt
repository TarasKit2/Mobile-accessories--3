package com.example.third

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class AuthActivity : AppCompatActivity() {
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_auth)

        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        val buttonRegistration = findViewById<Button>(R.id.button)
        val buttonLogin = findViewById<Button>(R.id.button2)
        val editTextLogin = findViewById<EditText>(R.id.editTextText3)
        val editTextPassword = findViewById<EditText>(R.id.editTextTextPassword3)

        buttonRegistration.setOnClickListener {
            val intent = Intent(this, RegistrationActivity::class.java)
            startActivity(intent)
            finish()
        }

        buttonLogin.setOnClickListener {
            val login = editTextLogin.text.toString()
            val password = editTextPassword.text.toString()

            if (checkCredentials(login, password)) {
                val intent = Intent(this, MenuActivity::class.java)
                startActivity(intent)
            } else {

                Toast.makeText(this, "Invalid login or password", Toast.LENGTH_SHORT).show()
            }
        }
    }


    private fun checkCredentials(login: String, password: String): Boolean {

        val savedLogin = sharedPreferences.getString("login", "")
        val savedPassword = sharedPreferences.getString("pass", "")


        return login == savedLogin && password == savedPassword
    }
}
