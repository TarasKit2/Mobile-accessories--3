package com.example.second

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_second)
        val button = findViewById<Button>(R.id.button)
        val txt = findViewById<EditText>(R.id.editTextText)

        button.setOnClickListener {
            val txt = txt.text.toString()
            if (txt == "1234") {
                val intent = Intent(this, CalculatorActivity::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Не правильно введені значення.", Toast.LENGTH_LONG)
                    .show()
            }

        }
    }
}