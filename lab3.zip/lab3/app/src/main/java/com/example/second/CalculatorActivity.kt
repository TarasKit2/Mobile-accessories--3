package com.example.second

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CalculatorActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_calculator)
        val button1 = findViewById<Button>(R.id.button1)
        val button2 = findViewById<Button>(R.id.button2)
        val button3 = findViewById<Button>(R.id.button3)
        val button4 = findViewById<Button>(R.id.button4)
        val button5 = findViewById<Button>(R.id.button5)
        val button6 = findViewById<Button>(R.id.button6)
        val button7 = findViewById<Button>(R.id.button7)
        val button8 = findViewById<Button>(R.id.button8)
        val button9 = findViewById<Button>(R.id.button9)
        val button10= findViewById<Button>(R.id.button10)
        val button11 = findViewById<Button>(R.id.button11)
        val button12 = findViewById<Button>(R.id.button12)
        val button13 = findViewById<Button>(R.id.button13)
        val button14 = findViewById<Button>(R.id.button14)
        val button0 = findViewById<Button>(R.id.button0)
        val button15 = findViewById<Button>(R.id.button15)
        val txt = findViewById<TextView>(R.id.textView2)
        val txt2 = findViewById<TextView>(R.id.textView3)
        val txt3 = findViewById<TextView>(R.id.textView4)

        button1.setOnClickListener(){
            val currentText = txt.text.toString()
            if (currentText == "0"){
                val newText = "1"
                txt.setText(newText)
            }else {
                val newText = currentText + "1"
                txt.setText(newText)
            }
        }
        button2.setOnClickListener(){
            val currentText = txt.text.toString()
            if (currentText == "0"){
                val newText = "2"
                txt.setText(newText)
            }else {
                val newText = currentText + "2"
                txt.setText(newText)
            }
        }
        button3.setOnClickListener(){
            val currentText = txt.text.toString()
            if (currentText == "0"){
                val newText = "3"
                txt.setText(newText)
            }else {
                val newText = currentText + "3"
                txt.setText(newText)
            }
        }
        button4.setOnClickListener(){
            val currentText = txt.text.toString()
            if (currentText == "0"){
                val newText = "4"
                txt.setText(newText)
            }else {
                val newText = currentText + "4"
                txt.setText(newText)
            }
        }
        button5.setOnClickListener(){
            val currentText = txt.text.toString()
            if (currentText == "0"){
                val newText = "5"
                txt.setText(newText)
            }else {
                val newText = currentText + "5"
                txt.setText(newText)
            }
        }
        button6.setOnClickListener(){
            val currentText = txt.text.toString()
            if (currentText == "0"){
                val newText = "6"
                txt.setText(newText)
            }else {
                val newText = currentText + "6"
                txt.setText(newText)
            }
        }
        button7.setOnClickListener(){
            val currentText = txt.text.toString()
            if (currentText == "0"){
                val newText = "7"
                txt.setText(newText)
            }else {
                val newText = currentText + "7"
                txt.setText(newText)
            }
        }
        button8.setOnClickListener(){
            val currentText = txt.text.toString()
            if (currentText == "0"){
                val newText = "8"
                txt.setText(newText)
            }else {
                val newText = currentText + "8"
                txt.setText(newText)
            }
        }
        button9.setOnClickListener(){
            val currentText = txt.text.toString()
            if (currentText == "0"){
                val newText = "9"
                txt.setText(newText)
            }else {
                val newText = currentText + "9"
                txt.setText(newText)
            }
        }

        button10.setOnClickListener(){
            val num1 = txt.text.toString().toInt()
            val num2 = txt3.text.toString().toInt()
            val text = txt2.text.toString()
            val result = when (text) {
                "+" -> num1 + num2
                "-" -> num2 - num1
                "/" -> if (num1 != 0) num2 / num1 else 0
                "*" -> num1 * num2
                else -> 0
            }
            txt3.setText(result.toString())
            txt.setText("0")

        }



        button11.setOnClickListener(){
            val currentText = txt.text.toString()
            val newChar = "+"
            txt.setText("0")
            txt2.setText(newChar)
            txt3.setText(currentText)


        }
        button12.setOnClickListener(){
            val currentText = txt.text.toString()
            val newChar = "-"
            txt.setText("0")
            txt2.setText(newChar)
            txt3.setText(currentText)


        }
        button13.setOnClickListener(){
            val currentText = txt.text.toString()
            val newChar = "/"
            txt.setText("0")
            txt2.setText(newChar)
            txt3.setText(currentText)


        }
        button14.setOnClickListener(){
            val currentText = txt.text.toString()
            val newChar = "*"
            txt.setText("0")
            txt2.setText(newChar)
            txt3.setText(currentText)


        }

        button0.setOnClickListener(){
            val currentText = txt.text.toString()
            if (currentText == "0"){
                val newText = "0"
                txt.setText(newText)
            }else {
                val newText = currentText + "0"
                txt.setText(newText)
            }
        }

        button15.setOnClickListener(){
            txt.setText("0")
            txt2.setText("")
            txt3.setText("")

        }
    }
}