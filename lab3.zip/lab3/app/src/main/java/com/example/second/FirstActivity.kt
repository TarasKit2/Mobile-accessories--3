package com.example.second

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat



class FirstActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_first)

        val img = findViewById<ImageView>(R.id.imageView)
        val txt = findViewById<TextView>(R.id.textView)
        img.setOnClickListener {
            txt.text = "1234"
        }
        txt.setOnClickListener {
            if (txt.text == "1234") {
                val intent = Intent(this, SecondActivity::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(
                    this,
                    "Текст та зображення не співпадають. Натисніть на зображення, щоб змінити текст.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}