package com.example.lab

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat



class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val img = findViewById<ImageView>(R.id.imageView)
        val txt = findViewById<TextView>(R.id.textView)
        img.setOnClickListener{
            txt.text = "Foto"
        }
        txt.setOnClickListener{
            if (txt.text =="Foto") {
                val intent = Intent(this, SecondActivity::class.java)
                startActivity(intent)
            }
                else{
                    Toast.makeText(this, "Текст і зображення не співпадають. Клікніть на фото, щоб змінити текст.", Toast.LENGTH_LONG).show()
                }
        }
    }

   // fun changeScreen(v: View) {
    //    val intent = Intent(this, SecondActivity::class.java)
   //     startActivity(intent)

  //  }



 //   fun changeSize(bitmap: Bitmap): Bitmap  {
  //      return Bitmap.createScaledBitmap(bitmap, 200,200, true)

  //  }


}

