package com.example.lab

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.os.CountDownTimer


class SecondActivity : AppCompatActivity() {

    private lateinit var countdownTimer: CountDownTimer
    private lateinit var countdownText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        countdownText = findViewById(R.id.countdownText)
        startTimer()
    }

    private fun startTimer() {
        countdownTimer = object : CountDownTimer(3000, 1000) {
            override fun onTick(millisUntilFinished: Long) {

                val n = millisUntilFinished / 1000

                countdownText.text = "$n...."
            }

            override fun onFinish() {
                countdownText.text = "Таймер закінчився! Вітаємо ви перейшли"
            }
        }
        countdownTimer.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        countdownTimer.cancel()
    }
}
